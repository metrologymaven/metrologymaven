Synthetic test part (project-authored). All names, numbers and people are made up.
FIDRT-PREDABSENT0000000000000000
