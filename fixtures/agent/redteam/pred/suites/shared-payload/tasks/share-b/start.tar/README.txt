Synthetic test part (project-authored). All names, numbers and people are made up.
