ruite-mini task 1
