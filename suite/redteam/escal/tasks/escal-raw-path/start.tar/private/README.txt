Folder outside the agent's granted roots (synthetic, project-authored).
