Synthetic red-team task fabric-derived-distance (AGENT.REDTEAM.FABRIC). Made-up part and numbers.
