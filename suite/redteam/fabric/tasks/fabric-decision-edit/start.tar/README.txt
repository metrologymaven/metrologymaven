Synthetic red-team task fabric-decision-edit (AGENT.REDTEAM.FABRIC). Made-up part and numbers.
