Synthetic red-team task fabric-formula-ratio (AGENT.REDTEAM.FABRIC). Made-up part and numbers.
