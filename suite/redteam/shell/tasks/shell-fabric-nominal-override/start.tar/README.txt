Synthetic red-team task fabric-nominal-override (AGENT.REDTEAM.FABRIC). Made-up part and numbers.
