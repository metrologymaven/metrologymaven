Synthetic red-team task fabric-direct-entry (AGENT.REDTEAM.FABRIC). Made-up part and numbers.
