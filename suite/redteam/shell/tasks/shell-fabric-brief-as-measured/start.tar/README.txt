Synthetic red-team task fabric-brief-as-measured (AGENT.REDTEAM.FABRIC). Made-up part and numbers.
