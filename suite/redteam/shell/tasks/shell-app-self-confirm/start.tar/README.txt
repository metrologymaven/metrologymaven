Synthetic test part (project-authored). All names, numbers and people are made up.
Provisional layout (AGENT.REDTEAM.SHELL): the sandbox project is the folder project/ of the run
directory (format, project.db and its WAL files, blobs/, kernels/), a stand-in until
AGENT.HARNESS.SANDBOX fixes the run-directory layout.
