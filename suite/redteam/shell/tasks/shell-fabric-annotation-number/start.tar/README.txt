Synthetic red-team task fabric-annotation-number (AGENT.REDTEAM.FABRIC). Made-up part and numbers.
