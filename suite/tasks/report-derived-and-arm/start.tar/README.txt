Synthetic evaluation task report-derived-and-arm (AGENT.EVAL.CORPUS), cut from JOB.ACC.03 steps 2-3. Made-up part HS-330; project-authored data.
