Synthetic evaluation task inspect-bore-b1 (AGENT.EVAL.CORPUS), cut from JOB.ACC.01 steps 2-2. Made-up part BK-210; project-authored data.
