Synthetic evaluation task probe-bolt-circle (AGENT.EVAL.CORPUS), cut from JOB.ACC.04 steps 4-12. Made-up part FL-480; project-authored data.
