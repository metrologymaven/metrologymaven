Synthetic evaluation task inspect-plate-holes (AGENT.EVAL.CORPUS), cut from JOB.ACC.01 steps 3-6. Made-up part BK-210; project-authored data.
