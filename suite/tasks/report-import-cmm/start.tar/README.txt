Synthetic evaluation task report-import-cmm (AGENT.EVAL.CORPUS), cut from JOB.ACC.03 steps 1-1. Made-up part HS-330; project-authored data.
