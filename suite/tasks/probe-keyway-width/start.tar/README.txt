Synthetic evaluation task probe-keyway-width (AGENT.EVAL.CORPUS), cut from JOB.ACC.04 steps 13-13. Made-up part FL-480; project-authored data.
