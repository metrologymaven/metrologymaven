Synthetic evaluation task inspect-bracket-fai (AGENT.EVAL.CORPUS), cut from JOB.ACC.01 steps 1-8. Made-up part BK-210; project-authored data.
