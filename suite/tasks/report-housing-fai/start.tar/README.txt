Synthetic evaluation task report-housing-fai (AGENT.EVAL.CORPUS), cut from JOB.ACC.03 steps 1-4. Made-up part HS-330; project-authored data.
