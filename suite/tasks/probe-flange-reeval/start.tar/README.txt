Synthetic evaluation task probe-flange-reeval (AGENT.EVAL.CORPUS), cut from JOB.ACC.04 steps 1-14. Made-up part FL-480; project-authored data.
